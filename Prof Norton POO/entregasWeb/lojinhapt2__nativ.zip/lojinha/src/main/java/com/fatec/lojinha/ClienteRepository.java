package com.fatec.lojinha;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente,Integer> {

    @Query(value = "SELECT * FROM cliente WHERE email = :email AND senha = :senha AND ativo = 1 LIMIT 1", nativeQuery = true)
    Cliente login(@Param("email") String email, @Param("senha") String senha);

    @Query(value = "SELECT senha FROM cliente WHERE email = :email AND ativo = 1 LIMIT 1", nativeQuery = true)
    String reenvioSenha(@Param("email") String email);

}
